Using ex4_print.asm will print "nul" between "result=" and the result's value; you can ignore it.



